
v0.0.3
- Added borders to crosshair for better visibility.
- Increased crosshair size
v0.0.4
- Crosshair now shrinks when crouching.
- Dot now appears when interactor is colliding.
- Crosshair now disappears when opening the settings.
v0.0.5
- Fixed crosshair turning into dot and vice versa when raising/lowering weapon while canted