extends "res://Scripts/Interactor.gd"

@onready var crosshair = Node2D.new()
var crosshair_size = 40.0
var crosshair_length = 10.0
var crosshair_thickness = 2.0
var crosshair_color = Color(1, 1, 1, 0.5)

var crosshair_border_color = Color(0, 0, 0, 0.75)
var crosshair_border_thickness = 1

var current_crosshair_offset = 0.0
var current_crosshair_rotation = 0.0
var current_cross_alpha = 1.0
var current_dot_alpha = 1.0
var current_knife_alpha = 1.0

var lean_angle = deg_to_rad(30.0)

var crosshairLerpSpeed = 10.0

var idle_offset = 0.0
var moving_offset = 20.0
var running_offset = 40.0
var interact_offset = 100.0

var crouching_offset_add = -20.0

var fired = false
var firing_offset_add = 10.0

func _ready():
    add_child(crosshair)
    crosshair.set_as_top_level(true)
    crosshair.draw.connect(_draw_crosshair)

func _physics_process(delta):
    super(delta)

    var is_weapon_equipped = gameData.primary || gameData.secondary || gameData.knife
    
    var target_offset = idle_offset
    var target_cross_alpha = 1.0
    var target_dot_alpha = 1.0
    var target_knife_alpha = 1.0

    var target_rotation = 0.0

    # offset
    if gameData.isMoving:
        if gameData.isRunning:
            target_offset = running_offset  # offset when sprinting
        else:
            target_offset = moving_offset  # offset when walking
    
    if gameData.isCrouching:
        target_offset += crouching_offset_add

    if gameData.interaction:
        target_offset = interact_offset  # offset when hovering over interactible
    
    if gameData.isAiming:
        target_offset = -crosshair_size + crosshair_length

    # impulse offsets

    if !gameData.isFiring:
        fired = false

    if gameData.isFiring && !fired:
        current_crosshair_offset += firing_offset_add
        fired = true

    # don't show cross if
    # - aiming (not canted)
    # - inspecting
    # - no weapon equipped
    # - weapon is down (and not aiming nor canted)
    # - interacting
    if (
        (gameData.isAiming && !gameData.isCanted)
        || gameData.isInspecting
        || !is_weapon_equipped
        || (gameData.weaponPosition == 1 && !(gameData.isAiming || gameData.isCanted))
        || gameData.interaction
    ):
        target_cross_alpha = 0.0
    else:
        if gameData.isRunning:
            target_cross_alpha = 0.75
        else:
            target_cross_alpha = 1.0

    # don't show dot if
    # - aiming or canted,
    # - inspecting,
    # - or weapon is equipped and not
    #   - interacting
    #   - wielding a knife
    #   - nor brought down
    if gameData.isAiming || gameData.isCanted || gameData.isInspecting || (is_weapon_equipped && !(gameData.interaction || gameData.knife || gameData.weaponPosition == 1)):
        target_dot_alpha = 1.0 if (is_colliding() && !gameData.isAiming) else 0.0
    else:
        target_dot_alpha = 1.0
    
    # don't show horizontal crosshair when holding knife
    if gameData.knife:
        target_knife_alpha = 0.0
    else:
        target_knife_alpha = 1.0

    # rotate crosshair accordingly
    if gameData.knife:
        target_rotation = deg_to_rad(-90.0)
    else:
        target_rotation = 0.0


    # lerp alpha
    current_cross_alpha = lerp(current_cross_alpha, target_cross_alpha, delta * crosshairLerpSpeed)
    current_dot_alpha = lerp(current_dot_alpha, target_dot_alpha, delta * crosshairLerpSpeed)
    current_knife_alpha = lerp(current_knife_alpha, target_knife_alpha, delta * crosshairLerpSpeed)
    # lerp offset
    current_crosshair_offset = lerp(current_crosshair_offset, target_offset, delta * crosshairLerpSpeed)
    # lerp rotation
    current_crosshair_rotation = lerp(current_crosshair_rotation, target_rotation, delta * crosshairLerpSpeed)
    
    # set values
    crosshair.set_rotation(current_crosshair_rotation)
    crosshair.set_position(get_viewport().get_visible_rect().get_center())
    crosshair.queue_redraw()

func _draw_crosshair():
    var is_interface_open = gameData.interface || gameData.settings

    if !is_interface_open:
        
        # south line
        draw_bordered_line(
            crosshair,
            Vector2(0, crosshair_size+current_crosshair_offset),
            Vector2(0, crosshair_size-crosshair_length+current_crosshair_offset),
            Color(crosshair_color, current_cross_alpha * crosshair_color.a),
            Color(crosshair_border_color, current_cross_alpha * crosshair_border_color.a),
            crosshair_thickness,
            crosshair_border_thickness
        )

        # north line
        draw_bordered_line(
            crosshair,
            Vector2(0, -crosshair_size - current_crosshair_offset),
            Vector2(0, -crosshair_size + crosshair_length - current_crosshair_offset),
            Color(crosshair_color, current_cross_alpha * crosshair_color.a),
            Color(crosshair_border_color, current_cross_alpha * crosshair_border_color.a),
            crosshair_thickness,
            crosshair_border_thickness
        )
        
        # east line
        draw_bordered_line(
            crosshair,
            Vector2(crosshair_size + current_crosshair_offset, 0),
            Vector2(crosshair_size - crosshair_length + current_crosshair_offset, 0),
            Color(crosshair_color, current_knife_alpha * current_cross_alpha * crosshair_color.a),
            Color(crosshair_border_color, current_knife_alpha * current_cross_alpha * crosshair_border_color.a),
            crosshair_thickness,
            crosshair_border_thickness
        )

        # west line
        draw_bordered_line(
            crosshair,
            Vector2(-crosshair_size - current_crosshair_offset, 0),
            Vector2(-crosshair_size + crosshair_length - current_crosshair_offset, 0),
            Color(crosshair_color, current_knife_alpha * current_cross_alpha * crosshair_color.a),
            Color(crosshair_border_color, current_knife_alpha * current_cross_alpha * crosshair_border_color.a),
            crosshair_thickness,
            crosshair_border_thickness
        )

        draw_crosshair_dot(crosshair)


func draw_bordered_line(rootNode: CanvasItem, fromPoint: Vector2, toPoint: Vector2, color: Color, borderColor: Color = Color(0, 0, 0, 1), thickness: float = 1.0, borderThickness: float = 1.0):
    
    # fill
    rootNode.draw_line(
        fromPoint,
        toPoint,
        color,
        thickness
    )

    var borderOffset = (thickness + borderThickness) / 2.0
    var theta = (toPoint - fromPoint).angle()
    
    # left border drawn up
    rootNode.draw_line(
        fromPoint + Vector2(0, -borderOffset).rotated(theta),
        fromPoint + Vector2(0, borderOffset).rotated(theta),
        borderColor,
        borderThickness
    )
    # top border drawn right
    rootNode.draw_line(
        fromPoint + Vector2(0, borderOffset).rotated(theta),
        toPoint + Vector2(0, borderOffset).rotated(theta),
        borderColor,
        borderThickness
    )
    # right border drawn down
    rootNode.draw_line(
        toPoint + Vector2(0, borderOffset).rotated(theta),
        toPoint + Vector2(0, -borderOffset).rotated(theta),
        borderColor,
        borderThickness
    )
    # bottom border drawn left
    rootNode.draw_line(
        toPoint + Vector2(0, -borderOffset).rotated(theta),
        fromPoint + Vector2(0, -borderOffset).rotated(theta),
        borderColor,
        borderThickness
    )

func draw_crosshair_dot(crosshairNode: CanvasItem):

    # filled dot
    crosshairNode.draw_circle(
        Vector2.ZERO,
        crosshair_thickness,
        Color(crosshair_color, current_dot_alpha * crosshair_color.a)
    )
    
    # dot outer border
    crosshairNode.draw_circle(
        Vector2.ZERO,
        crosshair_thickness + crosshair_border_thickness/2,
        Color(crosshair_border_color, current_dot_alpha * crosshair_border_color.a),
        false,  # not filled
        crosshair_border_thickness
    )