extends "res://Scripts/HUD.gd"

func _physics_process(_delta):
    var tooltip_base = gameData.tooltip
    gameData.tooltip = "\n\n\n" + tooltip_base
    super(_delta)
    gameData.tooltip = tooltip_base
