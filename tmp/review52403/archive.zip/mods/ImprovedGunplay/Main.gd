extends Node

func _ready():
	overrideScript("res://mods/ImprovedGunplay/Weapon.gd")
	overrideScript("res://mods/ImprovedGunplay/Inspect.gd")
	overrideScript("res://mods/ImprovedGunplay/Handling.gd")
	overrideScript("res://mods/ImprovedGunplay/Noise.gd")
	overrideScript("res://mods/ImprovedGunplay/Inputs.gd")
	queue_free()

func overrideScript(overrideScriptPath : String):
	var script : Script = load(overrideScriptPath)
	script.reload()
	var parentScript = script.get_base_script();
	script.take_over_path(parentScript.resource_path)