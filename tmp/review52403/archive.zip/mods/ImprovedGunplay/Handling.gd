extends "res://Scripts/Handling.gd"

var wasAiming = false
var wasHigh = false

func _physics_process(delta):
    if gameData.freeze:
        return

    if gameData.isPlacing:
        gameData.weaponPosition = 1
        targetPosition = weaponData.collisionPosition
        targetRotation = weaponData.collisionRotation

    elif gameData.isInspecting:
        targetPosition = weaponData.inspectPosition
        targetRotation = weaponData.inspectRotation

    else:

        if collision.is_colliding():
            gameData.isColliding = true
        else:
            gameData.isColliding = false

        if gameData.isColliding:
            targetPosition = weaponData.collisionPosition
            targetRotation = weaponData.collisionRotation

        else:

            # if gameData.isRunning || gameData.isPreparing || gameData.isReloading && (gameData.weaponType == 0 || gameData.weaponType == 1):
            if gameData.isRunning || gameData.isPreparing:

                if gameData.aimMode == 1:  # hold aim
                    if Input.is_action_pressed(("aim")):
                        wasAiming = true
                    else:
                        wasAiming = false
                elif gameData.aimMode == 2:
                    if Input.is_action_just_pressed(("aim")):
                        aimToggle = !aimToggle
                    wasAiming = aimToggle

                gameData.isAiming = false
                if wasAiming:
                    gameData.isCanted = true
                    if gameData.isPreparing:
                        targetPosition = weaponData.aimPosition - Vector3(0, get_parent().aimOffset, 0)
                        targetRotation = weaponData.aimRotation
                    else:
                        targetPosition = weaponData.cantedPosition
                        targetRotation = weaponData.cantedRotation
                else:
                    gameData.isCanted = false
                    if gameData.weaponPosition == 2:
                        targetPosition = weaponData.lowPosition
                        targetRotation = weaponData.lowRotation
                    elif gameData.weaponPosition == 1:
                        if gameData.isPreparing:
                            targetPosition = weaponData.lowPosition
                            targetRotation = weaponData.lowRotation
                        else:
                            targetPosition = weaponData.collisionPosition
                            targetRotation = weaponData.collisionRotation
                
                lerpSpeed = 6.0
                    
            else:
                # hold aim
                if gameData.aimMode == 1:
                    if Input.is_action_pressed(("aim")):
                        
                        if Input.is_action_just_pressed(("canted")) && !gameData.interaction:
                            canted = !canted

                        if canted:
                            gameData.isCanted = true
                            gameData.isAiming = false
                            targetPosition = weaponData.cantedPosition
                            targetRotation = weaponData.cantedRotation
                            lerpSpeed = 6.0
                        else:
                            gameData.isCanted = false
                            gameData.isAiming = true
                            targetPosition = weaponData.aimPosition - Vector3(0, get_parent().aimOffset, 0)
                            targetRotation = weaponData.aimRotation
                            lerpSpeed = 7.5
                        wasAiming = gameData.isAiming

                    elif !gameData.isColliding:
                        wasAiming = false
                        gameData.isAiming = false
                        gameData.isCanted = false

                        if gameData.weaponPosition == 2:
                            targetPosition = weaponData.highPosition
                            targetRotation = weaponData.highRotation
                            lerpSpeed = 6.0
                        else:
                            targetPosition = weaponData.lowPosition
                            targetRotation = weaponData.lowRotation
                            lerpSpeed = 6.0

                # toggle aim
                elif gameData.aimMode == 2:
                    if Input.is_action_just_pressed(("aim")):
                        aimToggle = !aimToggle

                    if aimToggle:

                        if Input.is_action_just_pressed(("canted")) && !gameData.interaction:
                            canted = !canted

                        if canted:
                            gameData.isCanted = true
                            gameData.isAiming = false
                            targetPosition = weaponData.cantedPosition
                            targetRotation = weaponData.cantedRotation
                            lerpSpeed = 6.0
                        else:
                            gameData.isCanted = false
                            gameData.isAiming = true
                            targetPosition = weaponData.aimPosition - Vector3(0, get_parent().aimOffset, 0)
                            targetRotation = weaponData.aimRotation
                            lerpSpeed = 7.5
                        
                        wasAiming = gameData.isAiming
                    else:
                        wasAiming = false
                        if !gameData.isColliding:
                            gameData.isAiming = false
                            gameData.isCanted = false

                            if gameData.weaponPosition == 2:
                                targetPosition = weaponData.highPosition
                                targetRotation = weaponData.highRotation
                                lerpSpeed = 6.0
                            else:
                                targetPosition = weaponData.lowPosition
                                targetRotation = weaponData.lowRotation
                                lerpSpeed = 6.0


    position = lerp(position, Vector3( - targetPosition.x, targetPosition.y, - targetPosition.z), delta * lerpSpeed)
    rotation_degrees.x = lerp(rotation_degrees.x, targetRotation.x, delta * lerpSpeed)
    rotation_degrees.y = lerp(rotation_degrees.y, targetRotation.y, delta * lerpSpeed)
    rotation_degrees.z = lerp(rotation_degrees.z, targetRotation.z, delta * lerpSpeed)

