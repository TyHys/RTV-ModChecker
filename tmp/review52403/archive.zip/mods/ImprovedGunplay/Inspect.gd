extends "res://Scripts/Inspect.gd"

func GetAmmoCount():
    var weaponIndex = 0
    if gameData.primary:
      weaponIndex = 0  # redundant, but just to be safe
    elif gameData.secondary:
      weaponIndex = 1
    ammoCount.text = "%d+%d" % [interface.equipmentGrid.get_child(weaponIndex).slotData.ammo, interface.equipmentGrid.get_child(weaponIndex).slotData.chamber]