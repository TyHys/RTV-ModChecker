extends "res://Scripts/Weapon.gd"

@onready var hitIndicator = Node2D.new()

@onready var laserDotMesh = SphereMesh.new()
@onready var laserDotMeshInstance = MeshInstance3D.new()

@onready var laserMesh = ImmediateMesh.new()
@onready var laserMeshInstance = MeshInstance3D.new()

var laserRaycaster
var laserLight
var laserFPSLight

var laserColor: Color = Color(1, 0, 0, 0.8)
var laserTarget = null
var laserTargetNormal = null

var hitIndicatorCross: bool = false
var hitIndicatorNoHit: bool = true
var hitIndicatorLength: float = 10.0
var hitIndicatorThickness: float = 1.0
var hitIndicatorBorderThickness: float = 1.0
var hitIndicatorColor: Color = Color(1, 1, 1, 0.8)
var hitIndicatorOffset: float = 5.0
var targetHitIndicatorOffset: float = 20.0
var hitIndicatorLerpSpeed: float = 10.0

var currentHitIndicatorPosition = null
var currentHitIndicatorAlpha: float = 0.0
var currentHitIndicatorOffset: float = 100.0

var wasFlashlight = false
# var laserState = 0  # off, flashlight, laser, both
var isLaserOn = false

# settings
var laserOptics = []
var allowHitIndicator = true
var allowLaser = true
var accurateLaser = false
var autoChamber = false

var __debug__ = false

var fullAutoStuck = false

func _ready():
    super()
    gameData.isInserting = false
    gameData.isInspecting = false

    isLaserOn = false

    # laser line
    muzzle.add_child(laserMeshInstance)

    var material := StandardMaterial3D.new()
    var laserNVGColor = Color(laserColor)
    laserNVGColor.s -= 0.1
    laserNVGColor.v += 0.3
    material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
    material.albedo_color = laserNVGColor
    material.flags_unshaded = true
    material.flags_transparent = true
    material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    material.emission_enabled = true
    material.emission = laserColor
    material.emission_energy = 6.0  # Increase for stronger glow
    material.blend_mode = BaseMaterial3D.BLEND_MODE_ADD  # Optional: laser-like additive glow

    laserMeshInstance.mesh = laserMesh
    laserMeshInstance.material_override = material
    laserMeshInstance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    laserMeshInstance.receive_shadows = false

    # 3D laser Dot
    laserDotMesh.height = 0.01
    laserDotMesh.radius = laserDotMesh.height/2
    laserDotMesh.radial_segments = 6  # Low poly for performance
    laserDotMesh.rings = 4
    laserDotMeshInstance.mesh = laserDotMesh
    muzzle.add_child(laserDotMeshInstance)

    var dotMaterial := StandardMaterial3D.new()
    dotMaterial.flags_unshaded = true
    dotMaterial.flags_transparent = true
    dotMaterial.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
    dotMaterial.blend_mode = BaseMaterial3D.BLEND_MODE_ADD
    dotMaterial.albedo_color = Color(laserNVGColor, 0.2)
    dotMaterial.emission_enabled = true
    dotMaterial.emission = Color(laserNVGColor, 1)
    dotMaterial.emission_energy = 6.0  # Make it very bright
    laserDotMeshInstance.material_override = dotMaterial
    
    laserDotMeshInstance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
    laserDotMeshInstance.receive_shadows = false
    
    laserLight = weaponManager.worldLight.duplicate()
    muzzle.add_child(laserLight)
    laserFPSLight = weaponManager.FPSLight.duplicate()
    muzzle.add_child(laserFPSLight)

    laserRaycaster = raycast.duplicate()
    laserRaycaster.position = Vector3(0, 0, 0)
    laserRaycaster.rotation_degrees = Vector3(0, 0, 0)
    laserRaycaster.target_position = Vector3(0, 0, 400)
    muzzle.add_child(laserRaycaster)

    # hit indicator
    add_child(hitIndicator)
    hitIndicator.set_as_top_level(true)
    hitIndicator.draw.connect(DrawHitIndicator)
    hitIndicator.rotation = deg_to_rad(45)
    hitIndicator.visible = allowHitIndicator

    ChamberRound()

func _physics_process(delta):
    super(delta)

    if accurateLaser:
        raycast.force_raycast_update()
    else:
        laserRaycaster.force_raycast_update()

    # laser
    if allowLaser && isLaserOn && !gameData.interface && !gameData.settings:
        if accurateLaser && raycast.is_colliding():
            laserTarget = raycast.get_collision_point()
            laserTargetNormal = raycast.get_collision_normal()
        elif laserRaycaster.is_colliding():
            laserTarget = laserRaycaster.get_collision_point()
            laserTargetNormal = laserRaycaster.get_collision_normal()
    else:
        laserTarget = null
        laserTargetNormal = null


    laserMeshInstance.visible = allowLaser && isLaserOn && gameData.NVG
    laserDotMeshInstance.visible = allowLaser && isLaserOn

    # render laser line
    laserMesh.clear_surfaces()
    if laserMeshInstance.visible:
        laserMesh.surface_begin(Mesh.PRIMITIVE_LINES)
        laserMesh.surface_add_vertex(Vector3(0.0, 0.0, 0.0))
        if laserTarget && accurateLaser:
            laserMesh.surface_add_vertex(muzzle.to_local(laserTarget))
        else:
            if laserTarget:
                laserMesh.surface_add_vertex(Vector3(0.0, 0.0, muzzle.to_local(laserTarget).z))
            else:
                laserMesh.surface_add_vertex(Vector3(0.0, 0.0, 400))
        laserMesh.surface_end()

    # render laser dot
    if laserTarget && laserDotMeshInstance.visible:
        
        var dotPosition
        if accurateLaser:
            dotPosition = muzzle.to_local(laserTarget)
        else:
            dotPosition = Vector3(0, 0, muzzle.to_local(laserTarget).z)
        laserDotMeshInstance.position = dotPosition
        laserDotMeshInstance.position.z -= 0.05
        laserDotMesh.height = max(0.01, 0.01 * laserDotMeshInstance.position.z / 8)
        laserDotMesh.radius = laserDotMesh.height / 2

        var laserLightMultiplier = (laserDotMeshInstance.position.z - 1)/30
        var laserLightRange = [0.005, 0.1125]
        var laserLightEnergy = [1, 0.9]
        
        var lightPosition = dotPosition + laserTargetNormal * laserLightRange[0]/1.5

        var omni_range = laserLightRange[0] + clampf(laserLightMultiplier, 0.0, 1.0) * (laserLightRange[1] - laserLightRange[0])
        var light_energy = laserLightEnergy[0] + clampf(laserLightMultiplier, 0.0, 1.0) * (laserLightEnergy[1] - laserLightEnergy[0])

        laserLight.position = lightPosition
        laserLight.light_color = Color(1, 0.3, 0.3)  # Pure red
        laserLight.omni_range = omni_range
        laserLight.light_energy = light_energy
        
        laserFPSLight.position = lightPosition
        laserFPSLight.light_color = Color(1, 0.3, 0.3)  # Pure red
        laserFPSLight.omni_range = omni_range
        laserFPSLight.light_energy = light_energy
    else:
        laserLight.omni_range = 0.0
        laserLight.light_energy = 0.0
        laserFPSLight.omni_range = 0.0
        laserFPSLight.light_energy = 0.0


    # hit indicator
    currentHitIndicatorAlpha = lerp(currentHitIndicatorAlpha, 0.0, delta * hitIndicatorLerpSpeed)
    currentHitIndicatorOffset = lerp(currentHitIndicatorOffset, targetHitIndicatorOffset, delta * hitIndicatorLerpSpeed)
    if currentHitIndicatorPosition:
        var camera = get_viewport().get_camera_3d()
        if camera:
            hitIndicator.position = camera.unproject_position(currentHitIndicatorPosition)
    # hitIndicator.set_position(get_viewport().get_visible_rect().get_center())
    hitIndicator.queue_redraw()

# aim zoom
func ADS(delta):
    if gameData.isAiming && !gameData.isColliding && activeOptic != null:

        if activeOptic.attachmentData.scope && !opticToggle:
            ocularOpacity = lerp(ocularOpacity, activeOptic.attachmentData.ocularOpacity, delta * 10)
            shadowSize = lerp(shadowSize, activeOptic.attachmentData.shadowSize, delta * 10.0)
            reticleSize = lerp(reticleSize, activeOptic.attachmentData.reticleSize, delta * 10.0)
            gameData.aimFOV = 15.0
            gameData.isScoped = true


        elif activeOptic.attachmentData.scope && opticToggle:
            ocularOpacity = lerp(ocularOpacity, 0.0, delta * 10)
            shadowSize = lerp(shadowSize, activeOptic.attachmentData.shadowSize, delta * 10.0)
            reticleSize = lerp(reticleSize, activeOptic.attachmentData.reticleSize, delta * 10.0)
            gameData.aimFOV = gameData.baseFOV - 15
            gameData.isScoped = false


        elif activeOptic.attachmentData.variable:

            if weaponSlot.slotData.zoom == 3:
                ocularOpacity = lerp(ocularOpacity, activeOptic.attachmentData.ocularOpacity, delta * 10)
                shadowSize = lerp(shadowSize, activeOptic.attachmentData.shadowSize, delta * 10.0)
                reticleSize = lerp(reticleSize, activeOptic.attachmentData.variableReticle.z, delta * 10.0)
                gameData.aimFOV = 10.0
                gameData.isScoped = true

            elif weaponSlot.slotData.zoom == 2:
                ocularOpacity = lerp(ocularOpacity, activeOptic.attachmentData.ocularOpacity, delta * 10)
                shadowSize = lerp(shadowSize, activeOptic.attachmentData.shadowSize, delta * 10.0)
                reticleSize = lerp(reticleSize, activeOptic.attachmentData.variableReticle.y, delta * 10.0)
                gameData.aimFOV = 25.0
                gameData.isScoped = true

            elif weaponSlot.slotData.zoom == 1:
                ocularOpacity = lerp(ocularOpacity, activeOptic.attachmentData.ocularOpacity, delta * 10)
                shadowSize = lerp(shadowSize, activeOptic.attachmentData.shadowSize, delta * 10.0)
                reticleSize = lerp(reticleSize, activeOptic.attachmentData.variableReticle.x, delta * 10.0)
                gameData.aimFOV = gameData.baseFOV - 15
                gameData.isScoped = false


        else:
            reticleSize = lerp(reticleSize, activeOptic.attachmentData.reticleSize, delta * 10.0)
            gameData.aimFOV = gameData.baseFOV - 15
            gameData.isScoped = false

    else:
        ocularOpacity = lerp(ocularOpacity, 0.0, delta * 10)
        gameData.aimFOV = gameData.baseFOV - 15
        gameData.isScoped = false


    ocular.set_shader_parameter("Opacity", ocularOpacity)
    shadow.set_shader_parameter("size", shadowSize)


    if activeOptic != null && activeOptic.reticle != null:
        activeOptic.reticle.set_shader_parameter("size", reticleSize)


func ReloadInput():
    if gameData.isInspecting || gameData.isReloading || gameData.isInserting:
        return

    if Input.is_action_just_pressed(("reload")):
        # print("Reload key pressed!")
        
        # semi-auto
        if (weaponData.action == 0 || weaponData.action == 1):
            if (weaponSlot.slotData.chamber == 1 && weaponSlot.slotData.ammo == weaponData.magazineSize) || !interface.AmmoCheck(weaponData):
                return
            
            # print("Reloading semi-auto weapon.")
            animator.active = true
            gameData.isReloading = true
            gameData.isFiring = false

            var chamberAmmo = 0

            if weaponSlot.slotData.chamber == 1:
                animator["parameters/conditions/Reload_Tactical"] = true
            else:
                animator["parameters/conditions/Reload_Empty"] = true
                # PlaySlideLockedAudio()
                weaponSlot.slotData.chamber = 1
                chamberAmmo = 1

            var ammoNeeded = weaponData.magazineSize - weaponSlot.slotData.ammo
            var ammoProvided = interface.Reload(ammoNeeded, weaponData)
            weaponSlot.slotData.ammo = weaponSlot.slotData.ammo + ammoProvided - chamberAmmo
        
        # manual-feed
        elif (weaponData.action == 2 || weaponData.action == 3):
            
            # Weapon prepared but ammo full/no ammo left; reload readies weapon
            if weaponSlot.slotData.ammo + (weaponSlot.slotData.chamber if weaponData.action == 2 else 0) >= weaponData.magazineSize || !interface.AmmoCheck(weaponData):
                # START: Ready Weapon
                if gameData.isPreparing:
                    animator.active = true
                    animator["parameters/conditions/Insert_Start"] = false
                    animator["parameters/conditions/Insert_End"] = true
                    gameData.isFiring = false
                    gameData.isPreparing = false
                    gameData.isInserting = false
                    if weaponData.action == 2 && weaponSlot.slotData.chamber == 0 && weaponSlot.slotData.ammo > 0:
                        weaponSlot.slotData.chamber = 1
                        weaponSlot.slotData.ammo -= 1
                # END: Ready Weapon

            # Weapon ready; reload prepares weapon
            elif !gameData.isPreparing:

                # START: Prepare Weapon
                if gameData.isInserting:
                    return
                animator.active = true
                animator["parameters/conditions/Insert_Start"] = true
                animator["parameters/conditions/Insert_End"] = false
                gameData.isFiring = false
                gameData.isPreparing = true
                if weaponData.action == 2 && weaponSlot.slotData.chamber == 1:
                    weaponSlot.slotData.chamber = 0
                    weaponSlot.slotData.ammo += 1
                # END: Prepare Weapon

            # Weapon prepared, can reload; reload inserts round
            else:
                # START: Insert Round
                animator.active = true
                animator["parameters/conditions/Insert"] = true
                gameData.isFiring = false
                gameData.isInserting = true                 
                var ammoProvided = interface.Reload(1, weaponData)
                weaponSlot.slotData.ammo += ammoProvided
                # END: Insert Round
                

    elif Input.is_action_just_pressed(("prepare")):
        # print("Prep key pressed!")
        # debug: removes round from chamber and adds it back to ammo pool
        if __debug__ && weaponSlot.slotData.chamber == 1:
            PlaySlideLockedAudio()
            weaponSlot.slotData.chamber = 0
            weaponSlot.slotData.ammo += 1
    elif Input.is_action_just_pressed(("insert")):
        # print("Insert round key pressed!")
        pass
    elif Input.is_action_just_pressed(("fire")):
        if (weaponData.action == 2 || weaponData.action == 3):
            # Ready weapon
            if gameData.isPreparing:
                animator.active = true
                animator["parameters/conditions/Insert_Start"] = false
                animator["parameters/conditions/Insert_End"] = true
                gameData.isFiring = false
                gameData.isPreparing = false
                gameData.isInserting = false
                if weaponData.action == 2 && weaponSlot.slotData.chamber == 0 && weaponSlot.slotData.ammo > 0:
                    weaponSlot.slotData.chamber = 1
                    weaponSlot.slotData.ammo -= 1

func ChamberRound(manualFeedOnly: bool = false):
    if gameData.isPreparing || gameData.isInserting || gameData.isFiring:
        return
    if (weaponSlot.slotData.ammo <= 0 || weaponSlot.slotData.chamber == 1):
        return
    if animator.active:
        return

    # semiautomatic weapons
    if (weaponData.action == 0 || weaponData.action == 1) && !manualFeedOnly:
        if weaponData.slideRelease:
            PlaySlideReleaseAudio()
        else:
            PlaySlideLockedAudio()
        weaponSlot.slotData.chamber = 1
        weaponSlot.slotData.ammo -= 1
        fullAutoStuck = true

    # manual-feed weapons
    elif (weaponData.action == 2 || weaponData.action == 3):
        animator.active = true
        gameData.isReloading = true
        gameData.isFiring = false
        animator["parameters/conditions/Reload"] = true
        animator["parameters/conditions/Insert_Start"] = false
        animator["parameters/conditions/Insert"] = false
        animator["parameters/conditions/Insert_End"] = false
        weaponSlot.slotData.ammo -= 1
        weaponSlot.slotData.chamber = 1

func FireInput():

    # handle firemode change
    if Input.is_action_just_pressed("firemode") && weaponData.action == 0 && !gameData.isReloading:
        ChangeFiremode()

    # don't process input if not ready to shoot
    if gameData.isInspecting || gameData.isReloading || gameData.isPreparing || gameData.isInserting:
        return
    
    if gameData.isRunning && !(gameData.isCanted || gameData.isAiming):
        return
    
    # don't process input if weapons have absolutely no ammo
    if weaponSlot.slotData.chamber == 0 && weaponSlot.slotData.ammo == 0:
        if Input.is_action_just_pressed(("fire")):
            PlayNoAmmoClick()
        return

    # don't process input if weapon is brought down
    if !gameData.weaponPosition == 2 && !gameData.isAiming && !gameData.isCanted:
        ChamberRound(true)
        if Input.is_action_just_pressed(("fire")):
            if gameData.weaponPosition == 1:
                gameData.weaponPosition = 2
                fullAutoStuck = true
        return

    # unstuck full auto
    if !Input.is_action_pressed(("fire")):
        fullAutoStuck = false
            
    # PROCESS FIRE INPUT

    if weaponData.action == 0:

        # semi-auto
        if weaponSlot.slotData.firemode == 1:
            if Input.is_action_just_pressed(("fire")):
                if weaponSlot.slotData.chamber == 1:
                    FireEvent()
                    fireImpulse = 0.1
                    fireRate = 0.1
                else:
                    ChamberRound()
        
        # full-auto
        elif weaponSlot.slotData.firemode == 2:
            if Input.is_action_pressed(("fire")) && !fullAutoStuck:
                if weaponSlot.slotData.chamber == 1:
                    FireEvent()
                    fireImpulse = weaponData.fireRate
                    fireRate = weaponData.fireRate
                else:
                    ChamberRound()

    elif weaponData.action == 1:
        
        # semi-only
        if Input.is_action_just_pressed(("fire")):
            if weaponSlot.slotData.chamber == 1:
                FireEvent()
                fireImpulse = 0.1
                fireRate = 0.1
            else:
                ChamberRound()

    elif (weaponData.action == 2 || weaponData.action == 3):

        # auto-chamber
        if autoChamber:
            ChamberRound()

        # manual-feed
        if Input.is_action_just_pressed(("fire")):
            if weaponSlot.slotData.chamber == 1 && !animator.active:
                FireEvent()
                fireImpulse = 0.1
                fireRate = 0.1 + (0.1 if autoChamber else 0)
            # manually chamber round
            elif !autoChamber:
                ChamberRound()

func FireEvent():
    if fireTimer < fireRate || weaponSlot.slotData.chamber == 0:
        return

    if weaponData.action == 3:
        for ray in 6:
            Raycast(0.5)
            raycast.force_raycast_update()
    else:
        Raycast(0.0)

    MuzzleEffect()
    PlayFireAudio()
    PlayTailAudio()
    recoil.ApplyRecoil()
    weaponSlot.slotData.chamber = 0
    fireTimer = 0.0

    if (weaponData.action == 0 || weaponData.action == 1) && weaponSlot.slotData.ammo > 0:
        CartridgeEject()
        weaponSlot.slotData.chamber = 1
        weaponSlot.slotData.ammo -= 1
        PlayCasingDrop()

    if weaponSlot.slotData.ammo == 0 && weaponSlot.slotData.chamber == 0 && weaponData.action == 1:
        PlaySlideLockedAudio()

    if activeMuzzle == null && !weaponData.nativeSuppressor:
        weaponManager.muzzleFlash = true

func Slide(delta):
    var currentPose = skeleton.get_bone_global_pose_no_override(slideIndex)

    if gameData.isFiring || (weaponData.slideLock && weaponSlot.slotData.chamber == 0):
        slideValue = lerp(slideValue, weaponData.slideMovement, delta * weaponData.slideSpeed)
    else:
        slideValue = lerp(slideValue, 0.0, delta * weaponData.slideSpeed)

    if gameData.isReloading:
        slideWeight = 0.0
    else:
        slideWeight = 1.0

    if weaponData.slideDirection == weaponData.SlideDirection.X:
        var slidePose = currentPose.translated_local(Vector3(slideValue, 0, 0))
        skeleton.set_bone_global_pose_override(slideIndex, slidePose, slideWeight, true)
    elif weaponData.slideDirection == weaponData.SlideDirection.Y:
        var slidePose = currentPose.translated_local(Vector3(0, slideValue, 0))
        skeleton.set_bone_global_pose_override(slideIndex, slidePose, slideWeight, true)
    elif weaponData.slideDirection == weaponData.SlideDirection.Z:
        var slidePose = currentPose.translated_local(Vector3(0, 0, slideValue))
        skeleton.set_bone_global_pose_override(slideIndex, slidePose, slideWeight, true)


    if activeOptic != null && activeOptic.slideFollow:
        var slideTransform = skeleton.get_bone_global_pose(slideIndex)
        var slidePosition = skeleton.to_global(slideTransform.origin + slideTransform.basis.y * activeOptic.slideOffsetY + slideTransform.basis.z * activeOptic.slideOffsetZ)
        activeOptic.global_position = slidePosition


func Raycast(spread: float):
    raycast.rotation_degrees.x = randf_range( - spread, spread)
    raycast.rotation_degrees.y = randf_range( - spread, spread)

    if raycast.is_colliding():
        var hitCollider = raycast.get_collider()
        var hitPoint = raycast.get_collision_point()
        var hitNormal = raycast.get_collision_normal()
        var hitSurface = raycast.get_collider().get("surfaceType")
        BulletDecal(hitCollider, hitPoint, hitNormal, hitSurface)

        var wasHit = false
        currentHitIndicatorPosition = hitPoint
        currentHitIndicatorOffset = hitIndicatorOffset
        if hitCollider is Hitbox:
            wasHit = true
            hitCollider.ApplyDamage(weaponData.damage)
            currentHitIndicatorAlpha = 1.0
            hitIndicatorCross = true

        if hitCollider.owner is Mine:
            wasHit = true
            hitCollider.owner.InstantDetonate()
            currentHitIndicatorAlpha = 1.0
            hitIndicatorCross = true
        
        if !wasHit && hitIndicatorNoHit:
            hitIndicatorCross = false
            currentHitIndicatorAlpha = 1.0

func PlayNoAmmoClick():
    var noAmmoClick = audioInstance2D.instantiate()
    add_child(noAmmoClick)
    noAmmoClick.PlayInstance(audioLibrary.unload)

func PlayLaserClick():
    var laserClick = audioInstance2D.instantiate()
    add_child(laserClick)
    laserClick.PlayInstance(audioLibrary.flashlight)

func _input(event):
    if gameData.isInspecting && !Input.is_action_pressed("rail_movement"):
        if event is InputEventMouseButton:
            if event.button_index == MOUSE_BUTTON_WHEEL_UP:
                if gameData.inspectPosition == 1:
                    animator["parameters/conditions/Inspect_Front"] = false
                    animator["parameters/conditions/Inspect_Back"] = true
                    gameData.inspectPosition = 2

            if event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
                if gameData.inspectPosition == 2:
                    animator["parameters/conditions/Inspect_Front"] = true
                    animator["parameters/conditions/Inspect_Back"] = false
                    gameData.inspectPosition = 1

    if Input.is_action_just_pressed("prepare_throw"):
        PlayLaserClick()
        isLaserOn = !isLaserOn

    if Input.is_action_just_pressed("secondary_optic"):
        if gameData.isAiming && activeOptic != null && activeOptic.attachmentData.secondary && activeOptic.secondary != null:
            opticToggle = !opticToggle

            if opticToggle:
                # Scopes are scaled when placing them on the guns,
                # but it seems the scale when adding the secondary optic position isn't accounted for,
                # resulting in this misalignment in the HMR.
                # - Oldman
                aimOffset = abs(raycast.position.y - (activeOptic.position.y + activeOptic.secondary.position.y * activeOptic.scale.y))
            else:
                aimOffset = abs(raycast.position.y - activeOptic.position.y)




    if gameData.isAiming && activeOptic != null && activeOptic.attachmentData.variable && !Input.is_action_pressed("rail_movement"):
        if event is InputEventMouseButton && event.is_pressed():
            if event.button_index == MOUSE_BUTTON_WHEEL_UP && weaponSlot.slotData.zoom != 3:
                weaponSlot.slotData.zoom += 1
                PlayRailMove()

            if event.button_index == MOUSE_BUTTON_WHEEL_DOWN && weaponSlot.slotData.zoom != 1:
                weaponSlot.slotData.zoom -= 1
                PlayRailMove()




    if gameData.isInspecting || gameData.isAiming || gameData.isCanted || gameData.weaponPosition == 1 || gameData.weaponPosition == 2:
        if activeOptic != null && activeOptic.railMovement:
            if Input.is_action_pressed("rail_movement"):
                if event is InputEventMouseButton && event.is_pressed():
                    if event.button_index == MOUSE_BUTTON_WHEEL_UP && activeOptic.position.z < activeOptic.maxPosition:
                        activeOptic.position.z += 0.01
                        weaponSlot.slotData.position += 0.01
                        PlayRailMove()
                    elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN && activeOptic.position.z > activeOptic.minPosition:
                        activeOptic.position.z -= 0.01
                        weaponSlot.slotData.position -= 0.01
                        PlayRailMove()
        
func DrawHitIndicator():
    var is_interface_open = gameData.interface || gameData.settings
    if !is_interface_open:

        if hitIndicatorCross:
            # south line
            hitIndicator.draw_line(
                Vector2(0, currentHitIndicatorOffset),
                Vector2(0, hitIndicatorLength+currentHitIndicatorOffset),
                Color(hitIndicatorColor, currentHitIndicatorAlpha * hitIndicatorColor.a),
                hitIndicatorThickness
            )

            # north line
            hitIndicator.draw_line(
                Vector2(0, -currentHitIndicatorOffset),
                Vector2(0, -(hitIndicatorLength+currentHitIndicatorOffset)),
                Color(hitIndicatorColor, currentHitIndicatorAlpha * hitIndicatorColor.a),
                hitIndicatorThickness
            )
            
            # east line
            hitIndicator.draw_line(
                Vector2(currentHitIndicatorOffset, 0),
                Vector2(hitIndicatorLength+currentHitIndicatorOffset, 0),
                Color(hitIndicatorColor, currentHitIndicatorAlpha * hitIndicatorColor.a),
                hitIndicatorThickness
            )

            # west line
            hitIndicator.draw_line(
                Vector2(-currentHitIndicatorOffset, 0),
                Vector2(-(hitIndicatorLength+currentHitIndicatorOffset), 0),
                Color(hitIndicatorColor, currentHitIndicatorAlpha * hitIndicatorColor.a),
                hitIndicatorThickness
            )
        else:
            # filled dot
            hitIndicator.draw_circle(
                Vector2.ZERO,
                hitIndicatorThickness,
                Color(hitIndicatorColor, currentHitIndicatorAlpha * hitIndicatorColor.a),
            )
            
            # dot outer border
            hitIndicator.draw_circle(
                Vector2.ZERO,
                hitIndicatorThickness + hitIndicatorBorderThickness/2,
                Color(hitIndicatorColor, currentHitIndicatorAlpha * hitIndicatorColor.a),
                false,  # not filled
                hitIndicatorBorderThickness
            )