extends "res://Scripts/Inputs.gd"

func _ready():
    ##  var laserAction = "laser"
    ##  inputs[laserAction] = "Laser"
    ##  super()
    ##  if !InputMap.has_action(laserAction):
    ##      InputMap.add_action(laserAction)
    ##      if preferences.action_events.has(laserAction):
    ##          var savedEvent = preferences.action_events[laserAction]
    ##          InputMap.action_erase_events(laserAction)
    ##          InputMap.action_add_event(laserAction, savedEvent)
    ##      else:
    ##          var key_event := InputEventKey.new()
    ##          key_event.keycode = KEY_PERIOD  # This is the '.' key
    ##          key_event.physical_keycode = KEY_PERIOD  # Optional but good for physical layout mapping
    ##          InputMap.action_add_event(laserAction, key_event)
    inputs["prepare_throw"] = "Prep Throw/Laser"
    super()
