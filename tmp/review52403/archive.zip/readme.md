**This mod already has Oldman's [ADS Zoom](https://modworkshop.net/mod/50828)**
**This mod has a different implementation of Oldman's [Reload Plus One](https://modworkshop.net/mod/50806)**
**This mod is incompatible with mods that edit the following files:**
- `Handling.gd` (Weapon positioning behavior)
- `Inputs.gd` (Changed label name for "Prepare Throw")
- `Inspect.gd` (Added indicator for bullet in chamber)
- `Noise.gd` (Decreased weapon sway)
- `Weapon.gd` (Majority of changes)
_This mod was inspired by [Ryhon's Simple Controls](https://modworkshop.net/mod/49778)._

With this mod, gunplay with manual-feed weapons is made easier and more intuitive with various changes to the reload mechanics.

Pressing the reload button with manual-feed weapons now does the following:
- If you cannot reload the weapon anymore, reload readies the weapon.
- Otherwise, if the weapon is ready, reload prepares the weapon for round insertion.
- Otherwise, reload inserts rounds into the weapon.

Pressing the fire button with manual-feed weapons now does the following:
- If the weapon is currently prepared to be loaded with rounds, fire readies it.
- If the chamber is ready, fires the weapon (obviously).
- If the chamber is empty, chambers a round.

Lowering a manual-feed weapon has you automatically chamber a round if the chamber is empty and the weapon has ammo in its magazine.

The changes to the fire and reload button functions allows for more intuitive gunplay especially in panicked situations (i.e. spamming the respective buttons if you want to reload or fire).

There are also changes made to the manual-feed rifle:
- Reading such weapons now chambers a round. (The animation shows the bolt being closed)
- Preparing such weapons now removes the chambered round (if there is any) and adds it back to its magazine.

You can now see if a weapon has a round present or absent in the chamber if you inspect the weapon, indicated by the "+1" or "+0" beside its ammo count, respectively.

### Changelog

v0.0.2
- Fixed reload key not doing anything in the case where the weapon is prepared, but there's no more ammo and the mag isn't full yet.

v0.0.3
- Fixed being able to reload mag-based weapons despite not having ammo.

v0.0.5
- Improved handling of edge case wherein a semi-automatic weapon has no round in chamber, preventing firing. Equipping or attempting to fire such a weapon now loads a round from its ammo pool into its chamber.

v0.0.6
- Fixed automatic fire not working.
- Fixed stray audio cues playing when reloading.
- Added sound indicator when ammo is completely spent.

v0.0.7
- Weapon is now positioned very low (as if it's colliding) when placing objects.
- Weapon is now positioned very low when running with the weapon lowered.
- When running while aiming, weapon automatically switches to canted version and returns to aim after running.
- Otherwise, weapon is brought down while running.
- You can now aim or un-aim your weapon while running, but you cannot shoot while running without aiming your weapon.
- Attempting to shoot your weapon while it is lowered will bring it up.

v0.0.8
- Bug fixes.

v0.0.9
- Decreased arm sway while aiming/canted/scoped. Arm stamina still affects this sway.
- Fix bug related to scope scaling, which Oldman pointed out:
  > (Paraphrased) ...From what I can see, the scopes are scaled when placing them on the guns, but it seems the scale when adding the secondary optic position isn't accounted for, resulting in this misalignment [with soviet guns] in the HMR.
- Added Hit Indicator; shows dots on misses, crosses on hits.

v0.0.10
- Added a laser, bound to the Prepare Throw keybind. For now, all weapons can use this.